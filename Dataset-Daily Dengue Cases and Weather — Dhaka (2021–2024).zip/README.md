# Daily Dengue Cases and Weather — Dhaka (2021–2024)

This dataset combines daily **dengue case counts** with **weather variables** for **Dhaka, Bangladesh**.

- **Coverage:** 2021-02-05 to 2024-12-31
- **Rows:** 1094
- **Columns:** 7
- **File:** `dhaka_dengue_weather_2021_2024.csv` (date format: `DD-MM-YY`)

## Columns
| Column | Type | Description |
|---|---|---|
| `Date` | string | Observation date in `DD-MM-YY`. |
| `District` | string | Administrative area; value is `Dhaka`. |
| `Dengue_Cases` | number | Daily reported dengue cases (may be missing). |
| `Temperature` | number | Daily mean temperature in °C. |
| `Humidity` | number | Daily mean relative humidity in %. |
| `Rainfall` | integer | Daily total rainfall in mm. |
| `Previous_Day_Dengue_Cases` | number | Lag-1 of dengue cases; missing where previous day is not available. |

## Missingness (share of rows with NA)
- `Dengue_Cases`: 33.36%
- `Previous_Day_Dengue_Cases`: 66.73%

> Note: Zeros are actual measured zeros (e.g., 0 mm rainfall), while missing values denote unavailable data.

## Suggested uses
- Time-series forecasting (ARIMA, Prophet, LSTM/GRU, CNN, attention-based models).
- Epidemiology–climate correlation analysis.
- Feature engineering with lags/rolling windows.

## Source & Attribution
- **Dengue cases:** *[Replace with your official source]* (e.g., DGHS daily reports).
- **Weather:** *[Replace with your official source]* (e.g., Bangladesh Meteorological Department).

Please cite the original sources if you re-use this dataset.

## License
Recommended: **CC BY 4.0** (change if needed).

## Changelog
- v1.0 (initial release): Uploaded raw daily data (cases + weather) for Dhaka.

## বাংলায় সংক্ষিপ্ত বিবরণ
এই ডেটাসেটটিতে ঢাকার দৈনিক ডেঙ্গু আক্রান্তের সংখ্যা ও আবহাওয়ার (তাপমাত্রা, আর্দ্রতা, বৃষ্টি) তথ্য একত্রে দেওয়া হয়েছে।
সময়কাল: ২০২১–২০২৪। ফাইলের তারিখ ফরম্যাট `DD-MM-YY`।
গবেষণা ও পূর্বাভাসের কাজে ব্যবহারযোগ্য। উৎস ও লাইসেন্স অংশে প্রয়োজনীয় তথ্য পূরণ করুন।
